使い方: nojs.exe build examples/hello.nojs
